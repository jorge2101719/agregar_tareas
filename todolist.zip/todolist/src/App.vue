<template>
    <div id="app">
        <h1>{{titular}}</h1>
        <input type="text" id="info" v-model="tarea">
        <button v-on:click="agregar">Agregar tarea</button>
        <h2>{{lista}}</h2>
        <ul v-for="(tarea, index) in tareas" :key="index">
            <li>
                {{index}} - {{tarea}}
            </li>     
        </ul>
    </div>
</template>

<script>
export default {
    name: "App",
    data() {
        return {
            titular: 'Agregar una nueva tarea',
            lista: 'Lista',
            tarea: '',
            tareas: []
        }
    },
    methods: {
        agregar: function() {
            this.tareas.push(this.tarea);
            this.tarea='';
        },
    }
};
</script>